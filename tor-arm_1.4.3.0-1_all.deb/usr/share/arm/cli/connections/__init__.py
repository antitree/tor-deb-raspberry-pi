"""
Connection panel related resources.
"""

__all__ = ["circEntry", "connEntry", "connPanel", "countPopup", "descriptorPopup", "entries"]

