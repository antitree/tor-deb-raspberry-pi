"""
Scripts involved in validating user input, system state, and initializing arm.
"""

__all__ = ["starter", "prereq", "version", "test"]

